r1=[LRmat.LRmat1;LRmat.LRmat2;LRmat.LRmat3];

init=lscov(r1,x1);